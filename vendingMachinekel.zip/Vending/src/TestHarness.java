/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
/**
 *
 * @author kelly
 */
public class TestHarness {
    
    static Item getItem(ArrayList<Item> itemlist,  String itemname) {
		for(int i=0;i<itemlist.size();++i) {
			if(itemlist.get(i).getName().equals(itemname)) {
				return itemlist.get(i);
			}
		}
		return null;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("\nWelcome to Vending Machine Shopping\n");
		
		ArrayList<Item> itemList=new ArrayList<>();
		
		itemList.add(new Item("chocolate", 2));
		itemList.add(new Item("cookies", 4));
		itemList.add(new Item("juice", 6));
		itemList.add(new Item("skittles", 1));
		itemList.add(new Item("mints", 3));
		
		
		System.out.println("Following items are present.");
		
		
		for(int i=0;i<5;++i) {
			System.out.println(itemList.get(i));
		}
		
		Scanner sc=new Scanner(System.in);   //to get user input

		System.out.print("Enter your name :");
		String customerName=sc.nextLine();
		
		System.out.print("Enter amount of money :");
		
		double customerMoney=sc.nextDouble();
		sc.nextLine();
		Customer customer=new Customer(customerName, new ArrayList<>(), customerMoney);
		
		while(true) {
			System.out.println("Enter number of items to be selected between 1-5");
			
			int num_items=sc.nextInt();
			sc.nextLine();
			
			if(num_items<5) {
				for(int i=0;i<num_items;) {
					System.out.println("Enter Item name to add");
					
					String itemName=sc.nextLine();
					if(getItem(itemList,itemName)!=null) {
						customer.getItemslist().add(getItem(itemList,itemName));
						i+=1;
						System.out.println("Item added successfully \n");
					}
					else {
						System.out.println("Item not found.Try again\n");
					}
				}
				break;
			}
			else {
				System.out.println("Number of elements cannot be greater than 5.Try again\n");
			}
		}
		
		int personality_number=new Random().nextInt(4);
		
		
		VendingMachine vendingMachine=new VendingMachine(Personality.values()[personality_number], customer);
		
		System.out.println("Random personality is "+vendingMachine.getPersonality());
		
		vendingMachine.setNumberOfItemsToSelect();
		
		
		System.out.println("Final Receipt.\n");
		System.out.println("Customer Name :"+vendingMachine.getCustomer().getName()+'\n');
		
		System.out.println("Items Selected :"+'\n');

		
		ArrayList<Item> finalItemsSelected=vendingMachine.getCustomer().getFirstNItems(vendingMachine.getItems_to_get());
		for(int i=0;i<finalItemsSelected.size();++i) {
			System.out.println(finalItemsSelected.get(i)+"\n");
		}
		
		System.out.println("Thanks for shopping");
	}
}
