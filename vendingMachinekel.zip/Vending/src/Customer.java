/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.ArrayList;
/**
 *
 * @author kelly
 */
public class Customer {
    
        String name;
	ArrayList<Item> itemslist;
	double money;
	public Customer(String name, ArrayList<Item> itemslist,double money) {
		super();
		this.name = name;
		this.itemslist = itemslist;
		this.money=money;
	}
	
	public double getMoney() {
		return money;
	}

	public void setMoney(double money) {
		this.money = money;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public ArrayList<Item> getItemslist() {
		return itemslist;
	}
	public void setItemslist(ArrayList<Item> itemslist) {
		this.itemslist = itemslist;
	}
	
	public ArrayList<Item> getFirstNItems(int n){  //returns the first n items from the customer item list
		ArrayList<Item> firstnItem=new ArrayList<>();
		if(n>itemslist.size()) {
			System.out.println("N is greater than number of items purchased by customer");
			return null;
		}
		else {
			for(int i=0;i<n;++i)
				firstnItem.add(itemslist.get(i));
			return firstnItem;
		}
	}   
}
