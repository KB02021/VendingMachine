/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Random;
/**
 *
 * @author kelly
 */
public class VendingMachine {
    
  Personality personality;
	Customer customer;
	int items_to_get=0;
	public VendingMachine(Personality personality, Customer customer) {
		super();
		this.personality = personality;
		this.customer = customer;
	}
	public Personality getPersonality() {
		return personality;
	}
	public void setPersonality(Personality personality) {
		this.personality = personality;
	}
	public Customer getCustomer() {
		return customer;
	}
	public int getItems_to_get() {
		return items_to_get;
	}
	public void setItems_to_get(int items_to_get) {
		this.items_to_get = items_to_get;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
	public void addItem(Item a) {
		customer.getItemslist().add(a);
		System.out.println("Item added to customer's cart");
	}
	
	public void setNumberOfItemsToSelect() {
		if(personality==Personality.Sunnyday) {
			items_to_get=2;
			System.out.println("Personality is Sunny day so 2 items to be selected\n");
		}
		else if(personality==Personality.Mehday) {
			System.out.println("Personality is Meh day so 1 items to be selected\n");
			items_to_get=1;
		}
		else if(personality==Personality.Rainyday) {
			System.out.println("Personality is Rainy day so either 0 or 1 items to be selected\n");
			items_to_get=new Random().nextInt(1); 
		}
		else if(personality==Personality.Nottodayday) {
			System.out.println("Personality is Not today day so 0 items to be selected\n");
			items_to_get=0;
		}
		
	}
	
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		
//	}  
}
